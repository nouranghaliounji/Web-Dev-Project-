<!DOCTYPE HTML>

<html>
	<head>
		<title>Write Up</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="home.css" />

	
	<body class="is-preload">

		<!-- Wrapper -->
			<div id="wrapper">



<?php

$conn = mysqli_connect("localhost", "root", "", "writeup");
if (!$conn) {
    die  ("connexion failed".mysqli_connect_error()); }

    
    $id = $_GET['id']; 
    $sql2= "DELETE FROM article WHERE id='$id'"; 
    $result2= mysqli_query($conn, $sql2); 
        if ($result2) {
             echo "This item has been deleted from the Database";
             echo "<a href='logout.php'><button style='margin-left': 400px;' class='box__button'>Log out</button></a> <br>";
            echo "<a href='administrator.php'><button style='margin-left': 400px;' class='box__button'>Return</button></a>"; }
        else {
            echo "Failed to delete record from the database"; 
        }

?>

    </div>
    </body>
    </head>
    </html>