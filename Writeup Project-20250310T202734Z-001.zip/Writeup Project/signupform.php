<!DOCTYPE HTML>




<!DOCTYPE HTML>

<html>
	<head>
		<title>sign up</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="sign up.css" /> 
		<script>
			
			function verify() {
                password1 = document.getElementById("pw").value;
				password2 = document.getElementById("pw2").value;
				username = document.getElementById("username").value;
                email = document.getElementById("email").value;

  
                // If password not entered
				if (username == '')
                    alert ("Please enter user name");
                    
				else if (email == '')
                    alert ("Please enter email");
                else if (password1 == '')
                    alert ("Please enter Password");
                      
                // If confirm password not entered
                else if (password2 == '')
                    alert ("Please enter confirm password");

				

                // If Not same return False.    
                else if (password1 != password2) {
                    alert ("\nPassword did not match: Please try again..."); 
                    return false;
                }
  
                // If same return True.
                else{
                    /*alert("Password Match: Welcome")*/
					location.replace("congrats.html"); 

                    return true;
                }
            }
			
			</script>
	</head>
	<body class="is-preload">



<!-- Header -->
		<header id="header">
			<h1><a href="index.php">Write Up</a></h1>
			<nav class="links">
				<ul>

					<li><a href="index.php">Magazine</a></li>
					<li><a href="ContactForm.php">Contact</a></li>
					<li><a href="About Us.php">About us</a></li>
					<li><a href="signupform.php">SIGN up</a></li>
					<li><a href="loginform.php">Log In</a></li>
				</ul>
			</nav>
			<nav class="main">
				<ul>
					<li class="search">
						<a class="fa-search" href="#search">Search</a>
						<form id="search" method="get" action="#">
							<input type="text" name="query" placeholder="Search" />
						</form>
					</li>
					<li class="menu">
						<a class="fa-bars" href="#menu">Menu</a>
					</li>
				</ul>
			</nav>
		</header>



<!--INTERACTIVE BAR-->
	<!-- Menu -->
		<section id="menu">

			

			<!-- Links -->
				<section>
					<ul class="links">
					<li>
							<a href="index.php">
								<h3>Magazine</h3>
								<p>Explore the newest releases on our website</p>
							</a>
						</li>
						<li>
							<a href="ContactForm.php">
								<h3>Contact</h3>
								<p>Contact us and reach out to us with any concerns</p>
							</a>
						</li>
						<li>
							<a href="About Us.php">
								<h3>About us</h3>
								<p>Get to know us more</p>
							</a>
						</li>
					</ul>
				</section>

			
				<section>
					<ul class="actions stacked">
						<li><a href="loginform.php" class="button large fit" onclick="openForm()">Log In</a></li>
					</ul>
				
					<ul class="actions stacked">
						<li><a href="signupform.php" class="button large fit">sign up</a></li>
					</ul>
				</section>
				
		</section>
		


		<script>
			function openForm() {
			  document.getElementById("myForm").style.display = "block";
			}
			
			function closeForm() {
			  document.getElementById("myForm").style.display = "none";
			}
			</script>

				<!-- Main -->
					<div id="main">
						<header>

						<!-- Post -->
							<article class="post">
								<h1>Sign up</h1>
								<form action= "<?php echo $_SERVER['PHP_SELF']?>" method= "POST">
									<table>
										<tr><td>Userame</td>
											<td><input type="text" id="username"name="username"> </td>
										</tr>
										
										<tr>
											<td>Email</td>
											<td><input type="email" id="email" name="email"> </td>
										</tr>
										<tr>
											<td>Password</td>
											<td><input type="password" name="pw" id="pw"> </td>
										</tr>
										<tr>
											<td>Confirm Password</td>
											<td><input type="password" name="pw2" id="pw2"> </td>
										</tr>
										<tr>
											<td>Type</td>
											<td><select name="types" id="type">
												
												<option value="writer">Writer</option>
												<option value="proofreader">Proofreader</option>
											</select>
											</td>
										</tr>
									</table>
									<button type="submit" name="Submit" onclick="verify()"> Signup</button>
								</form>


								
                                            <?php
					
	
					                        $con = mysqli_connect("localhost","root","","writeup");

					                        if (!$con) {
					                          die("Connection failed: ". mysqli_connect_error());
					                        }
                                            if (isset($_POST['Submit'])) {
					                        $username= $_POST['username'];
					                        $email= $_POST['email']; 
					                        $pw= $_POST['pw'];
					                        $type= $_POST['types']; 
					                        $s= " SELECT* FROM users where username= '$username'";
					                        $result= mysqli_query($con,$s);
					                        $num= mysqli_num_rows($result);
					                        if ($num==1){
					                        	echo "Username Already Taken";
					                        } 
											else {
						                        $reg= "insert into users(username,email,pw,types) values('$username','$email','$pw','$type')";
						                        $req= mysqli_query($con,$reg);
												if ($req) {
												echo"<script> location.replace('congrats.html');  </script>"; } 
					        
       
					                        }
                                                                }

					                        ?>
							</article>


					</div>
                                        

				
					

			</div>
			<footer id="footer">
				<p class="copyright">&copy; These atricles are the property of their articles solely</p>
			  </footer>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>
                       
