<!DOCTYPE HTML>

<html>
	<head>
		<title>Write Up</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="home.css" />

	
	<body>

		
			<div id="wrapper">



<?php

$conn = mysqli_connect("localhost", "root", "", "writeup");
if (!$conn) {
    die  ("connexion failed".mysqli_connect_error()); }

   

        $id = $_GET['id']; 
        $sql = "SELECT * FROM article WHERE id='$id'"; 
        $result = mysqli_query($conn, $sql); 
        $row = mysqli_fetch_assoc($result); 


        $title=$row['title'];
		$author=$row['writer_name'];
        $article=$row['article'];
        $image= $row['picture']; 
      
	
		$req1="insert into published_articles(article_title,writer_name,article_text,image) values('$title','$author','$article','$image')";
		$res1=mysqli_query($conn,$req1);
			if ($res1)

			 { 
                $sql2= "DELETE FROM article WHERE id='$id'"; 
                $result2= mysqli_query($conn, $sql2); 
                         echo "This item is now stored in the published_articles database and has been published <br>";  
                        echo "<a href='logout.php'><button style='margin-left': 400px;' class='box__button'>Log out</button></a> <br>";
                        echo "<a href='administrator.php'><button style='margin-left': 400px;' class='box__button'>Return</button></a>";
                     }
                         
                               
			 				
			 
	        else {
              echo "<div> Publication was unsuccessful </div>";    } 

            
    

?>
</div>

            
            </body>
            </head>
            </html>