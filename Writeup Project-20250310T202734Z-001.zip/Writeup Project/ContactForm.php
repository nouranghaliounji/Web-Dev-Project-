<head>
	<link rel="stylesheet" href="assets/css/main.css" />
	<style>

		.middle{
		margin:auto; 
    	display: flex;
  		justify-content: center;

		}


	</style>
	<title>Contact Us</title>
	</head>
	<body>
	
	
	<!-- Wrapper -->
            <div id="wrapper">

                <!-- Header -->
                    <header id="header">
                        <h1><a href="index.php">Write Up</a></h1>
                        <nav class="links">
                            <ul>
                                <li><a href="index.php">Magazine</a></li>
                                <li><a href="ContactForm.php">Contact</a></li>
                                <li><a href="About Us.php">About us</a></li>
                                <li><a href="signupform.php">SIGN up</a></li>
                                <li><a href="loginform.php">LOG IN</a></li>
                            </ul>
                        </nav>
                        <nav class="main">
                            <ul>
                                <li class="search">
                                    <a class="fa-search" href="#search">Search</a>
                                    <form id="search" method="get" action="search.php">
                                        <input type="text" name="query" placeholder="Search" />
                                    </form>
                                </li>
                                <li class="menu">
                                    <a class="fa-bars" href="#menu">Menu</a>
                                </li>
                            </ul>
                        </nav>
                    </header>



            <!--INTERACTIVE BAR-->
                <!-- Menu -->
                    <section id="menu">

                        <!-- Links -->
                            <section>
                                <ul class="links">
                                <li>
                                        <a href="index.php">
                                            <h3>Magazine</h3>
                                            <p>Explore the newest releases on our website</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ContactForm.php">
                                            <h3>Contact</h3>
                                            <p>Contact us and reach out to us with any concerns</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="About Us.php">
                                            <h3>About us</h3>
                                            <p>Get to know us more</p>


                                        </a>
                                    </li>
                                </ul>
                            </section>


                          
                            <section>
                                <ul class="actions stacked">
                                    <li><a href="loginform.php" class="button large fit" onclick="openForm()">Log In</a></li>
                                </ul>
                            
                                <ul class="actions stacked">
                                    <li><a href="signupform.php" class="button large fit">Sign up</a></li>
                                </ul>
                            </section>
                            
                    </section>
	
	
	
	
	<div class="middle">
	
                    <form class="box" method="post" action="" enctype="multipart/form-data">
                        <div class="box__input">
						<h1>Contact Form</h1>
                          Name: <input type="text" name="name"> <br>
						  Email: <input type="text" name="email"> <br><br>
						  message: <textarea name="message" cols="40" rows="5"></textarea> <br>


                          <button class="box__button" type="submit" name="Submit" onclick="sub()">Submit</button>
                        </div>

                      </form>

					  <script> 
					  function sub()
					  {alert("Your article has been submitted. Please wait for our editors to review it!");  }</script>
	
	</div>
		
				

				<script>
					function alr() {
						alert ("Your message was received. We'll get back to you soon!");
					}
				</script>
				
				
	
	
	<?php
	if (isset($_POST['Submit']))
	{

		$conn=mysqli_connect("localhost","root","","writeup");
			if (!$conn)
			{
			die("connexion failed".mysqli_connect_error());
			}


		$name=$_POST['name'];
		$email=$_POST['email'];
		$message=$_POST['message'];
		

		
		
		
		$req1="insert into contact (name,email,message) values ('$name','$email','$message') ";
		$res1=mysqli_query($conn,$req1);
			if ($res1)
			 {
					echo "";
			 }
					
			 
	else {echo "<div>There was a problem with your request.</div>";}}
		 			 
	
	?>
	
				<script src="assets/js/jquery.min.js"></script>
				<script src="assets/js/browser.min.js"></script>
				<script src="assets/js/breakpoints.min.js"></script>
				<script src="assets/js/util.js"></script>
				<script src="assets/js/main.js"></script>
	
	</body>
	</html>
	