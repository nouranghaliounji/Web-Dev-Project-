<?php

session_start();

if($_SESSION['status']!="Active")
{
    header("location:loginform.php");
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Writer page</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
        <link rel="stylesheet" href="writer.css" />
        <body>
              <!-- Wrapper -->

	
					
					<div id="outer">
					<p id="msg">
						Dear WriteUp Writer, <br> 
						Welcome to your space. Here, you can attach the file containing your article, then press "submit".
						Our editors will receive the article on their page, review it, and then publish it. 
					</p>
				</div>
				<br>
				<br>



                    <div id="box">
                    <form class="box" method="post" action="" enctype="multipart/form-data">
                        <div class="box__input">
                          Title: <input type="text" name="title"> <br>
						  Name of the author: <input type="text" name="nameAuthor"> <br><br>
						  Image: <input type="file" name="Image"> <br><br>
						  Article: <textarea name="Article" cols="40" rows="20"></textarea> <br>


                          <button class="box__button" type="submit" name="Submit" onclick="sub()">Submit</button>
                        </div>
                       
                      </form>
					  
					
					<br><br>
					
					<a href="logout.php"><button style="margin-left: 400px;" class="box__button" action="">Log out</button></a>

					<br><br><br><br><br><br>
					  <script> 
					  function sub()
					  {alert("Your article has been submitted. Please wait for our editors to review it!");  }</script>
                    </div>
					
<?php
	if (isset($_POST['Submit']))
	{
		$conn=mysqli_connect("localhost","root","","writeup");
			if (!$conn)
			{
			die("connexion failed".mysqli_connect_error());
			}


		$title=$_POST['title'];
		$author=$_POST['nameAuthor'];
		$image= $_FILES['Image']['name'];
		$article=$_POST['Article'];
		
		$target = "imagesTrial/".basename($image);

		
		
		
		$req1="insert into article (writer_name,title,picture,article) values ('$author','$title','$image','$article') ";
		$res1=mysqli_query($conn,$req1);
			if ($res1)
			 {
					echo "";
			 }
					
			 
	else {echo "<div>There was problem with your request.</div>";}}
		 			 
	
	?>

							<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
                    
        </body>
    </head>
</html>