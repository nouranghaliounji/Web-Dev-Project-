<!DOCTYPE HTML>

<html>
	<head>
		<title>Write Up</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="home.css" />

	
	<body class="is-preload">

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
					<header id="header">
						<h1><a href="index.php">Write Up</a></h1>
						<nav class="links">
							<ul>
								<li><a href="index.php">Magazine</a></li>
								<li><a href="ContactForm.php">Contact</a></li>
								<li><a href="About Us.php">About us</a></li>
								<li><a href="signupform.php">SIGN up</a></li>
								<li><a href="loginform.php">LOG IN</a></li>
							</ul>
						</nav>
						<nav class="main">
							<ul>
								<li class="search">
									<a class="fa-search" href="#search">Search</a>
									<form id="search" method="get" action="search.php">
										<input type="text" name="query" placeholder="Search" />
									</form>
								</li>
								<li class="menu">
									<a class="fa-bars" href="#menu">Menu</a>
								</li>
							</ul>
						</nav>
					</header>



			<!--INTERACTIVE BAR-->
				<!-- Menu -->
					<section id="menu">

						<!-- Links -->
							<section>
								<ul class="links">
								<li>
										<a href="index.php">
											<h3>Magazine</h3>
											<p>Explore the newest releases on our website</p>
										</a>
									</li>
									<li>
										<a href="ContactForm.php">
											<h3>Contact</h3>
											<p>Contact us and reach out to us with any concerns</p>
										</a>
									</li>
									<li>
										<a href="About Us.php">
											<h3>About us</h3>
											<p>Get to know us more</p>


										</a>
									</li>
								</ul>
							</section>


						  
							<section>
								<ul class="actions stacked">
									<li><a href="loginform.php" class="button large fit" onclick="openForm()">Log In</a></li>
								</ul>
							
								<ul class="actions stacked">
									<li><a href="signupform.php" class="button large fit">Sign up</a></li>
								</ul>
							</section>
							
					</section>
					


					<script>
						function openForm() {
						  document.getElementById("myForm").style.display = "block";
						}
						
						function closeForm() {
						  document.getElementById("myForm").style.display = "none";
						}
						</script>


<!--Main content of the page-->
				<!-- Main -->
                <div id="main">
                    <?php 
                        $conn = mysqli_connect("localhost", "root", "", "writeup");
                        if (!$conn) {
                            die  ("connexion failed".mysqli_connect_error()); }

                            $sql = "SELECT * FROM published_articles;";
                            $result = mysqli_query($conn, $sql); 

                            if (mysqli_num_rows($result) > 0) {
                            while($row = mysqli_fetch_assoc($result)) {

								$paragr= $row['article_text']; 
								$title= $row['article_title']; 
        
                              echo 
                              "<article class='post'>
                              <header>
                                  <div class='title'>
                                      <h2> <a href ='writeuparticle.php?id={$row['id']}'>".strtok($title," ")." </a> </h2> 
									  <p>".$title."</p> </div>
							
									  <div class='meta'>
									  
										<span class='name'> By ".$row['writer_name']."</span>
									</div>
                              </header>
                              <a href='writeuparticle.php?id={$row['id']}' class='image featured'>"; 
                              echo "<img src='images/".$row['image']."'>"."</a> 
							  <p>".strtok($paragr, ".")."..."."</p>
                              <footer>
                                  <ul class='actions'>
                                      <li><a href = 'writeuparticle.php?id={$row['id']}' class='button large'> Continue Reading</a></li>
                                  </ul>
                              </footer>
                          </article> "; 
							}}

                    ?>
                </div>




                <section id="sidebar">

<!-- Intro -->
    <section id="intro">
        <img id="logo" src="logo.png" alt="" />
        <header>
            <h2>Write Up</h2>
            <p>The home of future writers</p>
        </header>
    </section>



<!-- About -->
    <section class="blurb">
        <h2>About</h2>
        <p>We are a dedicated team that allows writers from around the world to share their voices and speak their minds. If you think that you have it in you to write for us, sign up today and submit your first article.</p>
        <ul class="actions">
            <li><a href="About Us.php" class="button">Learn More</a></li>
        </ul>
    </section>
<!--Contact-->
<section class="blurb">
    <h2>Contact</h2>
    <p>Through here, you can reach out to us with any suggestions, issues and requests you might have. Please note that your feedback is very important to us and we always aim to help our readers and writers as we best can.</p>
    <ul class="actions">
        <li><a href="ContactForm.php"class="button">Contact Form</a></li>
    </ul>
</section>

<!-- Footer -->
    <section id="footer">
    <p class="copyright">&copy; These atricles are the property of their articles solely</p>
    </section>

</section>

</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>

</body>
</head>
</html>