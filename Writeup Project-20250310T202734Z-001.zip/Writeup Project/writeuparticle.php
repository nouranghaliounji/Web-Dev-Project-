<!DOCTYPE HTML>

<html>
	<head>
		<title>Write Up</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="home.css" />

	</head>
	<body class="is-preload">

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
					<header id="header">
						<h1><a href="index.php">Write Up</a></h1>
						<nav class="links">
							<ul>
								<li><a href="index.php">Magazine</a></li>
								<li><a href="ContactForm.php">Contact</a></li>
								<li><a href="About Us.php">About us</a></li>
								<li><a href="signupform.php">SIGN up</a></li>
								<li><a href="loginform.php">LOG IN</a></li>
							</ul>
						</nav>
						<nav class="main">
							<ul>
								<li class="search">
									<a class="fa-search" href="#search">Search</a>
									<form id="search" method="get" action="search.php">
										<input type="text" name="query" placeholder="Search" />
									</form>
								</li>
								<li class="menu">
									<a class="fa-bars" href="#menu">Menu</a>
								</li>
							</ul>
						</nav>
					</header>



			<!--INTERACTIVE BAR-->
				<!-- Menu -->
					<section id="menu">

						<!-- Links -->
							<section>
								<ul class="links">
								<li>
										<a href="index.php">
											<h3>Magazine</h3>
											<p>Explore the newest releases on our website</p>
										</a>
									</li>
									<li>
										<a href="ContactForm.php">
											<h3>Contact</h3>
											<p>Contact us and reach out to us with any concerns</p>
										</a>
									</li>
									<li>
										<a href="About Us.php">
											<h3>About us</h3>
											<p>Get to know us more</p>


										</a>
									</li>
								</ul>
							</section>


						  
							<section>
								<ul class="actions stacked">
									<li><a href="loginform.php" class="button large fit" onclick="openForm()">Log In</a></li>
								</ul>
							
								<ul class="actions stacked">
									<li><a href="signupform.php" class="button large fit">Sign up</a></li>
								</ul>
							</section>
							
					</section>


				<script>
					function openForm() {
					  document.getElementById("myForm").style.display = "block";
					}
					
					function closeForm() {
					  document.getElementById("myForm").style.display = "none";
					}
					</script>


<?php 


$conn = mysqli_connect("localhost", "root", "", "writeup");
if (!$conn) {
    die  ("connexion failed".mysqli_connect_error()); }

?>
<!-- Main -->
<div id="main">

<!-- Post -->
    <article class="post">
        <?php
        if (isset($_GET['id'])) {
         $id = $_GET['id']; 
        echo "<header>"; 
        $sql = "SELECT * FROM published_articles WHERE id='$id';"; 
        $result = mysqli_query($conn, $sql); 
        $row = mysqli_fetch_assoc($result); 
        echo "<div class='title'> 
                <h2>".$row['article_title']."</h2>
            </div>
            <div class='meta'>
                <span class='name'>".$row['writer_name']."</span>
            </div>
        </header>
        <span class='image featured'>"; 
        echo "<img src='images/".$row['image']."'>"."<br>
        <p>".$row['article_text']."</p>";

        }
        
        ?>
									
		</article>
       
		</div>
        </div>

      

     

      

	<!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>