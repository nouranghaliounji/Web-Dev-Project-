<?php


  

session_start();
$con = mysqli_connect("localhost", "root", "","writeup");

if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}



if (isset($_POST['Submit'])) {

  $email= $_POST['email']; 
  $pw= $_POST['pw'];
    

  $sql = "SELECT * FROM users WHERE email='$email' AND pw='$pw' ";
  $res = mysqli_query($con,$sql);
  if(mysqli_num_rows($res)==1)
  {
    $row= mysqli_fetch_assoc($res);
    $_SESSION['username'] = $row['username'];
    $_SESSION['email'] = $row['email'];
    $_SESSION['pw'] = $row['pw'];
    $_SESSION['types'] = $row['types'];
    if($row['types']=="writer"){
      header("location:writer.php");
      $_SESSION['status']="Active";
    }
    else if($row['types']=="proofreader"){
      header("location:administrator.php");
      $_SESSION['status']="Active";
        }
    
    
    
    

    
    
}         

            
}

?>

<!DOCTYPE HTML>

<html>
	<head>
		<title>sign up</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="sign up.css" /> 
		<script>
			
			function verify() {
                password1 = document.getElementById("pw").value;
				password2 = document.getElementById("pw2").value;
				username = document.getElementById("username").value;
                email = document.getElementById("email").value;

  
                // If password not entered
				if (username == '')
                    alert ("Please enter user name");
                    
				else if (email == '')
                    alert ("Please enter email");
                else if (password1 == '')
                    alert ("Please enter Password");
                      
                // If confirm password not entered
                else if (password2 == '')
                    alert ("Please enter confirm password");

				

                // If Not same return False.    
                else if (password1 != password2) {
                    alert ("\nPassword did not match: Please try again...")
                    return false;
                }
  
                // If same return True.
                else{
                    /*alert("Password Match: Welcome")*/
					location.replace("congrats.html")

                    return true;
                }
            }
			
			</script>
	</head>
	<body class="is-preload">



		<!-- Header -->
		<header id="header">
			<h1><a href="index.php">Write Up</a></h1>
			<nav class="links">
				<ul>

					<li><a href="index.php">Magazine</a></li>
					<li><a href="ContactForm.php">Contact</a></li>
					<li><a href="About Us.php">About us</a></li>
					<li><a href="signupform.php">SIGN up</a></li>
					<li><a href="loginform.php">Log In</a></li>
				</ul>
			</nav>
			<nav class="main">
				<ul>
					<li class="search">
                                           <a class="fa-search" href="#search">Search</a>
                                           <form id="search" method="get" action="search.php">
                                           <input type="text" name="query" placeholder="Search" />
                                           </form>
                                        </li>
					<li class="menu">
						<a class="fa-bars" href="#menu">Menu</a>
					</li>
				</ul>
			</nav>
		</header>



<!--INTERACTIVE BAR-->
	<!-- Menu -->
		<section id="menu">

			

			<!-- Links -->
				<section>
					<ul class="links">
					<li>
							<a href="index.php">
								<h3>Magazine</h3>
								<p>Explore the newest releases on our website</p>
							</a>
						</li>
						<li>
							<a href="ContactForm.php">
								<h3>Contact</h3>
								<p>Contact us and reach out to us with any concerns</p>
							</a>
						</li>
						<li>
							<a href="About Us.php">
								<h3>About us</h3>
								<p>Get to know us more</p>
							</a>
						</li>
					</ul>
				</section>

			
				<section>
					<ul class="actions stacked">
						<li><a href="loginform.php" class="button large fit" onclick="openForm()">Log In</a></li>
					</ul>
				
					<ul class="actions stacked">
						<li><a href="signupform.php" class="button large fit">sign up</a></li>
					</ul>
				</section>
				
		</section>
		


		<script>
			function openForm() {
			  document.getElementById("myForm").style.display = "block";
			}
			
			function closeForm() {
			  document.getElementById("myForm").style.display = "none";
			}
			</script>

				<!-- Main -->
					<div id="main">
						<header>

							<!-- Intro -->
							<section id="intro">
								<div id="logo1"><img id="logo" src="logo.png" alt="" /></div>
								
								<div id="titles"> 
								<h2>Write Up</h2>
								<p>The home of future writers</p>
								</div>
							</section>
						</header>

						<!-- Post -->
							<article class="post">
								<h1>Log In</h1>
								<form action= "loginform.php" method="POST">
									<table>
										<tr><td>Email</td>
											<td><input type="text" id="email"name="email"> </td>
										</tr>
										
									
										<tr>
											<td>Password</td>
											<td><input type="password" name="pw" id="pw"> </td>
										</tr>
                                                                                </table>
                                                                                <button type="submit" name="Submit" onclick="verify()">Log In </button>
                                                                               
										
								</form>
                                                                  <br>

					                       	
                                                                
							</article>
                                         


					</div>

				
					

			</div>
			<footer id="footer">
				<p class="copyright">&copy; These atricles are the property of their articles solely</p>
			  </footer>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>
