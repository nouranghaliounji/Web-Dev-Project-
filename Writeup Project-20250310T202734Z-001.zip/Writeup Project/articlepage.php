<!DOCTYPE HTML>
<html>
	<head>
		<title>Article From Writer</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="single is-preload">

	<body>
              <!-- Wrapper -->
	 <div id="wrapper">
	
		<!-- Header -->
			<header id="header">
				<h1> WRITEUP</h1>
				<nav class="links">
					<ul>
						<li> <a href ="administrator.php">  Administrator page </a></li>	
						<li> <a href ="logout.php">  Log out </a></li>
					</ul>
				</nav>

			</header>
			</div>

<?php 


$conn = mysqli_connect("localhost", "root", "", "writeup");
if (!$conn) {
    die  ("connexion failed".mysqli_connect_error()); }

?>
<!-- Main -->
<div id="main">

<!-- Post -->
    <article class="post">
        <?php
        if (isset($_GET['id'])) {
         $id = $_GET['id']; 
        echo "<header>"; 
        $sql = "SELECT * FROM article WHERE id='$id';"; 
        $result = mysqli_query($conn, $sql); 
        $row = mysqli_fetch_assoc($result); 
        echo "<div class='title'> 
                <h2>".$row['title']."</h2>
            </div>
            <div class='meta'>
                <span class='name'> By ".$row['writer_name']."</span>
            </div>
        </header>
        <span class='image featured'>"; 
        echo "<img src='images/".$row['picture']."'> <br> "; 
        echo "<p>".$row['article']."</p>";
		
        echo " <form method='GET'> <button type='submit' name='submit'> <a href = 'Submitted.php?id={$row['id']}'</a> Publish </button> 
        <button name= 'delete'> <a href = 'Delete.php?id={$row['id']}'</a>  Delete </button> <form>"; 





        }
        
        ?>
									
		</article>
       
		</div>
        </div>

      

     
<!-- Delete article from DB -->
      

	<!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>