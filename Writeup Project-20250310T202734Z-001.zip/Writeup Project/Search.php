<!DOCTYPE HTML>
<html>
	<head>
		<title>Article From Writer</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="single is-preload">

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
				<header id="header">
					<h1><a href="index.php">Write Up</a></h1>
					<nav class="links">
						<ul>
						<li><a href="index.php">Magazine</a></li>
								<li><a href="ContactForm.php">Contact</a></li>
								<li><a href="About Us.php">About us</a></li>
								<li><a href="signupform.php">SIGN up</a></li>
								<li><a href="loginform.php">LOG IN</a></li>
						</ul>
					</nav>
					<nav class="main">
						<ul>
							<li class="search">
								<a class="fa-search" href="#search">Search</a>
								<form id="search" method="get" action="#">
									<input type="text" name="query" placeholder="Search" />
								</form>
							</li>
							<li class="menu">
								<a class="fa-bars" href="#menu">Menu</a>
							</li>
						</ul>
					</nav>
				</header>



		<!--INTERACTIVE BAR-->
			<!-- Menu -->
				<section id="menu">

	

					<!-- Links -->
						<section>
							<ul class="links">
							<li>
									<a href="index.php">
										<h3>Magazine</h3>
										<p>Explore the newest releases on our website</p>
									</a>
								</li>
								<li>
									<a href="ContactForm.php">
										<h3>Contact</h3>
										<p>Contact us and reach out to us with any concerns</p>
									</a>
								</li>
								<li>
									<a href="About Us.php">
										<h3>About us</h3>
										<p>Get to know us more</p>
									</a>
								</li>
							</ul>
						</section>

				
						<section>
							<ul class="actions stacked">
								<li><a href="loginform.php" class="button large fit" onclick="openForm()">Log In</a></li>
							</ul>
						
							<ul class="actions stacked">
								<li><a href="signupform.php" class="button large fit">sign up</a></li>
							</ul>
						</section>
						
				</section>
				


				<script>
					function openForm() {
					  document.getElementById("myForm").style.display = "block";
					}
					
					function closeForm() {
					  document.getElementById("myForm").style.display = "none";
					}
					</script>


<?php 

echo "<h1> Search Results </h1>";
$conn = mysqli_connect("localhost", "root", "", "writeup");
if (!$conn) {
    die  ("connexion failed".mysqli_connect_error()); }

    //if (isset($_GET['search'])) {

        $search = mysqli_real_escape_string($conn, $_GET['query']); //ensures safety; 

        $sql ="SELECT * FROM published_articles WHERE article_title LIKE '%$search%' OR writer_name LIKE '%$search%' 
        OR article_text LIKE '%$search%' ";

        $result = mysqli_query($conn, $sql);
        $res = mysqli_num_rows($result);

        echo "There are ".$res." results"; 

        if ($res > 0) {
            while ($row = mysqli_fetch_assoc($result)) {

                
								$paragr= $row['article_text']; 
								$title= $row['article_title'];
                echo 
                "<article class='post'>
                <header>
                    <div class='title'>
                        <h2><a href='Iran article.html'>".strtok($title, " ")." </a></h2>
                        <p>".$title."</p>
                        <div class='meta'>
                          <a href='#' class='author'><span class='name'> By ".$row['writer_name']."</span></a>
                      </div>
                </header>
                <a href='writeuparticle.php?id={$row['id']}' class='image featured'>"; 
                echo "<img src='images/".$row['image']."'>"."</a> 
                <p>".strtok($paragr, ".")."..."."</p>
                <footer>
                    <ul class='actions'>
                        <li><a href = 'writeuparticle.php?id={$row['id']}' class='button large'> Continue Reading</a></li>
                    </ul>
                </footer>
            </article> "; 
            }

        }

        else {
            echo "There are no results matching your search"; 
        }

?>

      

     

      

	<!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>