<?php

session_start();

if($_SESSION['status']!="Active")
{
    header("location:loginform.php");
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Writer page</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
        <link rel="stylesheet" href="writer.css" />
        <style>
        ul{list-style:none;}
        span{ text-decoration:none !important;}
        a {
        border-bottom:none;
        }
        .container {
        justify-content: center;
        margin-left: 5%; 
        margin-right: 5%; }
		#ad {
			
		}
</style>
        <body>
              <!-- Wrapper -->
	 <div id="wrapper">
	
		<!-- Header -->
			<header id="header">
				<h1> WRITEUP</h1>
				<nav class="links">
					<ul>
					<li> <a href ="administrator.php">  Administrator page </a></li>	
						<li> <a href ="logout.php">  Log out </a></li>
					</ul>
				</nav>

			</header>
			</div>
	
			
	

<div class='container'>
<div class='row p-4 no-gutters align-items-center'> 
<table>
<form>

<div id= hde>
<tr> <th> Author Name  </th> <th> Title of the Article </th> <th> Article id </th> </div>
<?php 

$conn = mysqli_connect("localhost", "root", "", "writeup");
			if (!$conn) {
				die  ("connexion failed".mysqli_connect_error()); }

$sql = "SELECT * FROM article;";
$result = mysqli_query($conn, $sql); 

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        
        echo "
        
        <tr>
             
            <td name= 'writer'> <span class='mb-0 text-muted'>".$row['writer_name']."</span> </td>
            
            <td name='title'> <a  href='articlepage.php?id={$row['id']}'>  <span>".$row['title']."</span></a></td> 
            <td name= 'id'>".$row['id']."</td> </tr>"; 

    }}


    
    else {
        echo "0 results"; }

      
        

?>
</form>
</table>
</div></div>


<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
                    
        </body>
    </head>
</html>